/*******
 * fcss.min.js本地白名单，适用于每次退出浏览器清除cookies的用户
 * 域名添加方法见下面例子，单域名、多域名、无域名。注意：最后一个域名后面没有逗号
*******/

//全局白名单
window.$$All_W = ["0.x-boy.cn"];

//CSP白名单
window.$$CSP_W = ["0.x-boy.cn","1.x-boy.cn"];

//疑似广告白名单
window.$$RAI_W = ["0.x-boy.cn","1.x-boy.cn","2.x-boy.cn"];

//全局广告白名单
window.$$ADV_W = [];

//阻止document.write加载外部脚本白名单
window.$$WRS_W = [];

//阻止非同源弹窗白名单
window.$$WWO_W = [];

//浮动元素白名单
window.$$Float_W = [];

//是否开启划词工具条:0关闭，1开启
window.$$selectSearch = 0;

//自定义划词搜索名称
//window.$$customStext = "自定义";

//自定义划词搜索地址-关键词用%s代替
//window.$$customSurl = "https://www.google.com/search?q=%s";